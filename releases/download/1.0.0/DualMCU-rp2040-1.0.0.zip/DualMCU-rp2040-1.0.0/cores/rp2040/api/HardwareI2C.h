#pragma once
#include "../../../ArduinoCore-API/api/HardwareI2C.h"
